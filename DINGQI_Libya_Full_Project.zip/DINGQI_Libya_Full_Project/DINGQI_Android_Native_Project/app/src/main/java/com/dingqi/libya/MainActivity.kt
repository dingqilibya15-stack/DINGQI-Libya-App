package com.dingqi.libya

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val baseUrl = "https://grand-dasik-40b1e0.netlify.app"
    private val whatsapp = "218946961543"
    private val pool = Executors.newFixedThreadPool(4)
    private val products = mutableListOf<JSONObject>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private var currency = "د.ل"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17,17,17)
        window.navigationBarColor = Color.rgb(17,17,17)
        buildScreen()
        loadProducts()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,247,249)) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,18,18,16); background = bg(Color.rgb(17,17,17), 0) }
        header.addView(TextView(this).apply { text = "DINGQI Libya"; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        header.addView(TextView(this).apply { text = "معدات الورش الاحترافية"; textSize = 14f; setTextColor(Color.rgb(245,164,0)); gravity = Gravity.RIGHT; setPadding(0,4,0,0) })
        root.addView(header)
        search = EditText(this).apply { hint = "ابحث عن منتج..."; textSize = 16f; singleLine = true; setPadding(14,8,14,8); background = bg(Color.WHITE, 14); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(search, LinearLayout.LayoutParams(-1, 52).apply { setMargins(14,14,14,6) })
        status = TextView(this).apply { text = "جارٍ تحميل المنتجات..."; textSize = 15f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(12,12,12,12) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,4,12,18) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        search.addTextChangedListener(SimpleWatcher { renderProducts() })
        setContentView(root)
    }

    private fun loadProducts() {
        status.text = "جارٍ تحميل المنتجات..."
        pool.execute {
            try {
                val arr = JSONArray(request("/api/products"))
                val settings = try { JSONObject(request("/api/settings")) } catch (_: Exception) { JSONObject() }
                val wa = settings.optString("whatsapp", "")
                runOnUiThread {
                    products.clear()
                    for (i in 0 until arr.length()) {
                        val p = arr.optJSONObject(i) ?: continue
                        if (p.optBoolean("active", true)) products.add(p)
                    }
                    currency = settings.optString("currency", "د.ل")
                    status.text = if (products.isEmpty()) "لا توجد منتجات متاحة حاليًا" else "${products.size} منتج متاح"
                    renderProducts()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذر تحميل المنتجات. تحقق من اتصال الإنترنت ثم أعد فتح التطبيق." }
            }
        }
    }

    private fun request(path: String): String {
        val conn = URL(baseUrl + path).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 12000
        conn.readTimeout = 15000
        conn.setRequestProperty("Accept", "application/json")
        try {
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            return stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { conn.disconnect() }
    }

    private fun renderProducts() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString().trim() else ""
        val shown = products.filter { it.optString("name").contains(q, true) || it.optString("category").contains(q, true) || it.optString("description").contains(q, true) }
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply { text = if (products.isEmpty()) "" else "لا توجد نتائج مطابقة"; textSize = 16f; gravity = Gravity.CENTER; setPadding(10,30,10,30) })
            return
        }
        shown.forEach { p ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = bg(Color.WHITE, 16); setPadding(10,10,10,10); layoutDirection = View.LAYOUT_DIRECTION_RTL; elevation = 2f }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; background = bg(Color.rgb(248,248,248), 12) }
            card.addView(image, LinearLayout.LayoutParams(112,112).apply { setMargins(0,0,10,0) })
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            info.addView(TextView(this).apply { text = p.optString("name", "منتج"); textSize = 17f; setTextColor(Color.rgb(25,25,25)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
            info.addView(TextView(this).apply { text = p.optString("category", "معدات ورش"); textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.RIGHT; setPadding(0,4,0,4) })
            val price = p.optDouble("salePrice", -1.0).takeIf { it >= 0 } ?: p.optDouble("price", 0.0)
            info.addView(TextView(this).apply { text = "${price.toLong()} $currency"; textSize = 18f; setTextColor(Color.rgb(190,119,0)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.RIGHT; setPadding(0,7,0,0) }
            btns.addView(Button(this).apply { text = "التفاصيل"; textSize = 11f; setOnClickListener { showDetails(p) } })
            btns.addView(Button(this).apply { text = "اطلب واتساب"; textSize = 11f; setOnClickListener { orderWhatsApp(p) } })
            info.addView(btns)
            card.addView(info, LinearLayout.LayoutParams(0,-2,1f))
            card.setOnClickListener { showDetails(p) }
            list.addView(card, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,5,0,10) })
            loadImage(p.optString("image", p.optJSONArray("images")?.optString(0) ?: ""), image)
        }
    }

    private fun loadImage(src: String, target: ImageView) {
        if (src.isBlank()) return
        pool.execute {
            try {
                val bitmap: Bitmap? = if (src.startsWith("data:image")) {
                    val comma = src.indexOf(','); if (comma < 0) null else BitmapFactory.decodeStream(ByteArrayInputStream(android.util.Base64.decode(src.substring(comma+1), android.util.Base64.DEFAULT)))
                } else {
                    val full = if (src.startsWith("http")) src else "$baseUrl/${src.trimStart('/')}"
                    val c = URL(full).openConnection(); c.connectTimeout = 10000; c.readTimeout = 10000
                    c.getInputStream().use { BitmapFactory.decodeStream(it) }
                }
                if (bitmap != null) runOnUiThread { target.setImageBitmap(bitmap) }
            } catch (_: Exception) { }
        }
    }

    private fun showDetails(p: JSONObject) {
        val price = p.optDouble("salePrice", -1.0).takeIf { it >= 0 } ?: p.optDouble("price", 0.0)
        val text = buildString {
            append(p.optString("description", "لا توجد تفاصيل إضافية."))
            append("\n\nالسعر: ${price.toLong()} $currency")
            append("\nالتصنيف: ${p.optString("category", "معدات ورش")}")
            if (p.has("stock")) append("\nالمتوفر: ${p.optInt("stock")} قطعة")
        }
        AlertDialog.Builder(this).setTitle(p.optString("name", "تفاصيل المنتج")).setMessage(text)
            .setPositiveButton("اطلب عبر واتساب") { _, _ -> orderWhatsApp(p) }
            .setNegativeButton("إغلاق", null).show()
    }

    private fun orderWhatsApp(p: JSONObject) {
        val price = p.optDouble("salePrice", -1.0).takeIf { it >= 0 } ?: p.optDouble("price", 0.0)
        val msg = "السلام عليكم، أريد طلب المنتج التالي من DINGQI Libya:\nالمنتج: ${p.optString("name")}\nالسعر: ${price.toLong()} $currency\nرابط المتجر: $baseUrl"
        val uri = Uri.parse("https://wa.me/$whatsapp?text=" + URLEncoder.encode(msg, "UTF-8"))
        try { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { Toast.makeText(this, "تعذر فتح واتساب", Toast.LENGTH_LONG).show() }
    }

    private fun bg(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    override fun onDestroy() { pool.shutdownNow(); super.onDestroy() }
}
